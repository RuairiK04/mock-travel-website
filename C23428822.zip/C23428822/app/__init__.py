from flask import Flask, session
from flask_babel import Babel

def get_locale():
    """Determine the user's language preference from session (default: English)."""
    if 'language' in session:
        return session['language']
    else:
        session['language'] = 'en'  # Default to English
    return session['language']

# Create the Flask app
app = Flask(__name__)
app.secret_key = 'a secret key'  # Required for session
app.config['BABEL_DEFAULT_LOCALE'] = 'en'  # Explicit default (optional but consistent)

# Initialize Babel with the locale selector
babel = Babel(app, locale_selector=get_locale)

# Import routes at the end to avoid circular imports
from app import routes