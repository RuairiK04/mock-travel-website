from app import app
from flask import render_template, session, redirect, request, url_for

from app import app
from flask import render_template, session, redirect, request


@app.route('/set_language/<language>')
def set_language(language):
    session.pop('language', None)
    session['language'] = language
    return redirect(request.referrer or '/')

@app.before_request
def set_session_language():
    if 'language' not in session:
        session['language'] = 'en'  # Default to english

#first page route
@app.route('/')
@app.route('/index')
def index():
    return (render_template("index.html"))

# Danish route
@app.route('/da')
def danish_home():
    return render_template('da/index.html')

# Greek route
@app.route('/el')
def greek_home():
    return render_template('el/index.html')

